#include <stdio.h>

int main()
{
   
    int num;
   
    printf ("Por favor informe um numero inteiro: ");
    scanf("%d",&num);
    printf("\n\n------------------------------------------\n");

printf(" CONTAGEM REGRESSIVA DO NUMERO %d \n",num);

 printf("------------------------------------------\n");
   for (int i=num; i >= 0; i--){
       printf ("%d, ",i);
   }
   
    return 0;
   
}
